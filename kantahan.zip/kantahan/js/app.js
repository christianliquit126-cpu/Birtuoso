// Kantahan UI: browsing, queue, player screen, mic. Uses globals from songs.js and engine.js
const $=i=>document.getElementById(i);
const G=[['Awiting Bayan','🏡','#f59e0b,#b91c1c'],['Pop','🎤','#ec4899,#7c3aed'],['Rock','🎸','#475569,#dc2626'],['Reggae','🌴','#16a34a,#facc15'],['Love Songs','💜','#a855f7,#ec4899'],['Dance','🌃','#06b6d4,#7c3aed']];
const gOf=s=>s.a.includes('Awiting')?'Awiting Bayan':{pop:'Pop',rock:'Rock',reggae:'Reggae',ballad:'Love Songs',edm:'Dance'}[s.s];
const ld=(k,d)=>{try{return JSON.parse(localStorage.getItem(k))||d}catch(e){return d}};
const sv=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}};
const fmt=s=>{s=Math.max(0,s|0);return (s/60|0)+':'+String(s%60).padStart(2,'0')};
let fav=ld('kt-fav',[]),hist=ld('kt-hist',[]),queue=[],qi=-1,view='genres',vg='';
const say=t=>{$('msg').textContent=t};

function browse(){
 const w=$('bw');
 if(view==='genres'){$('bt').textContent='Genres';
  w.className='tiles';
  w.innerHTML=G.map(g=>`<button class="tile" data-g="${g[0]}" style="background:linear-gradient(135deg,${g[2]})"><i>${g[1]}</i>${g[0]}</button>`).join('');return}
 const q=$('q').value.trim().toLowerCase();
 let ids=SONGS.map((_,i)=>i),t='Lahat ng kanta';
 if(view==='genre'){ids=ids.filter(i=>gOf(SONGS[i])===vg);t=vg}
 if(view==='fav'){ids=fav.filter(i=>SONGS[i]);t='Favorites'}
 if(view==='hist'){ids=hist.filter(i=>SONGS[i]);t='History'}
 if(view==='search'){ids=ids.filter(i=>(SONGS[i].n+' '+SONGS[i].a).toLowerCase().includes(q));t='Resulta: '+q}
 $('bt').textContent=t;w.className='';
 w.innerHTML=ids.length?ids.map(i=>`<div class="sr"><button data-p="${i}" aria-label="Play">▶</button><div><b>${SONGS[i].n}</b><small>${SONGS[i].a} · ${SONGS[i].b} BPM</small></div><button data-f="${i}" aria-label="Favorite">${fav.includes(i)?'♥':'♡'}</button><button data-a="${i}" aria-label="Idagdag sa queue">＋</button></div>`).join(''):'<p class="em">Wala pa rito.</p>';
}
$('bw').onclick=e=>{
 const b=e.target.closest('button');if(!b)return;const d=b.dataset;
 if(d.g){view='genre';vg=d.g;browse()}
 else if(d.p!==undefined)playNow(+d.p);
 else if(d.a!==undefined){add(+d.a);say('Naidagdag sa queue')}
 else if(d.f!==undefined){const i=+d.f;fav=fav.includes(i)?fav.filter(x=>x!==i):[i,...fav];sv('kt-fav',fav);browse()}};
$('nav').onclick=e=>{const b=e.target.closest('button');if(!b)return;
 [...$('nav').children].forEach(x=>x.classList.toggle('on',x===b));$('q').value='';view=b.dataset.v;browse()};
$('q').oninput=()=>{view=$('q').value.trim()?'search':'genres';browse()};

function rq(){
 $('qc').textContent=queue.length+' kanta';
 $('qb').innerHTML=queue.map((x,k)=>`<tr class="${k===qi?'cu':''}" data-k="${k}"><td>${k===qi?'▶':k+1}</td><td>${SONGS[x].n}</td><td>${SONGS[x].a}</td></tr>`).join('');
}
$('qb').onclick=e=>{const r=e.target.closest('tr');if(r){qi=+r.dataset.k;load()}};
function load(){
 init();song=SONGS[queue[qi]];tr=0;$('kv').textContent='Key 0';
 hist=[queue[qi],...hist.filter(x=>x!==queue[qi])].slice(0,30);sv('kt-hist',hist);
 $('ti').textContent=song.n;$('ar').textContent=song.a;
 clearInterval(iv);ctx.resume();paused=0;t0=ctx.currentTime+.2;nt=t0;n=0;fin=0;started=1;score=0;cur=-2;
 iv=setInterval(sched,25);$('pb').textContent='⏸';say('');rq();
}
function playNow(i){if(qi<0){queue=[i];qi=0}else{queue.splice(qi+1,0,i);qi++}load()}
function add(i){queue.push(i);if(qi<0){qi=0;load()}else rq()}
function next(){if(qi<queue.length-1){qi++;load()}else say('Wala nang susunod sa queue.')}

$('pb').onclick=()=>{if(!song){say('Pumili muna ng kanta.');return}
 if(fin){load();return}
 if(paused){ctx.resume();paused=0;$('pb').textContent='⏸'}else{ctx.suspend();paused=1;$('pb').textContent='▶'}};
$('nx').onclick=next;
const key=d=>{tr+=d;$('kv').textContent='Key '+(tr>0?'+':'')+tr};
$('kd').onclick=()=>key(-1);$('ku').onclick=()=>key(1);
$('vol').oninput=e=>{init();M.gain.value=+e.target.value};
$('ec').oninput=e=>{$('ev').textContent=Math.round(e.target.value*100)+'%';if(wet)wet.gain.value=+e.target.value};
$('mic').onclick=async()=>{
 try{init();
  if(mc){mc.getTracks().forEach(t=>t.stop());mc=null;wet=null;ma=null;$('mic').textContent='🎤 Mic';$('mic').classList.remove('on');$('sc').textContent='';return}
  const s=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:false,noiseSuppression:false}});
  const src=ctx.createMediaStreamSource(s),dry=ctx.createGain(),dl=ctx.createDelay(1),fb=ctx.createGain();
  wet=ctx.createGain();dl.delayTime.value=.2;fb.gain.value=.35;wet.gain.value=+$('ec').value;
  ma=ctx.createAnalyser();ma.fftSize=512;
  src.connect(ma);src.connect(dry);dry.connect(ctx.destination);src.connect(dl);dl.connect(fb);fb.connect(dl);dl.connect(wet);wet.connect(ctx.destination);
  mc=s;score=0;$('sc').textContent='⭐ 0';$('mic').textContent='🎤 Patayin';$('mic').classList.add('on');
 }catch(e){say('Hindi mabuksan ang mic. Payagan ang microphone sa browser.')}};

const LY=[...$('ly').children],cv=$('cv'),c2=cv.getContext("2d");
function tick(ts){
 requestAnimationFrame(tick);
 const dt=Math.min(.1,(ts-lastT)/1000);lastT=ts;
 if(cv.width!==cv.clientWidth){cv.width=cv.clientWidth;cv.height=cv.clientHeight}
 c2.clearRect(0,0,cv.width,cv.height);
 if(an){const f=new Uint8Array(an.frequencyBinCount),W=cv.width,H=cv.height,k=f.length*.7|0,bw=W/k;
  an.getByteFrequencyData(f);c2.fillStyle='rgba(255,255,255,.28)';
  for(let i=0;i<k;i++){const h=f[i]/255*H*.5;c2.fillRect(i*bw,H-h,bw-2,h)}}
 if(!song||!started)return;
 const barD=240/song.b,pos=ctx.currentTime-t0,end=(INTRO+song.L.length*BPL)*barD;
 $('pg').style.width=Math.min(100,Math.max(0,pos/end*100))+'%';
 $('el').textContent=fmt(pos);$('rm').textContent='-'+fmt(end-pos);
 const u=pos/barD-INTRO,idx=u<0?-1:Math.min(song.L.length-1,Math.floor(u/BPL));
 if(idx!==cur){cur=idx;const b=Math.max(0,idx);[b-1,b,b+1,b+2].forEach((j,k)=>LY[k].textContent=song.L[j]||'')}
 LY[1].style.setProperty('--p',idx>=0&&pos<end?(((u/BPL)-idx)*100).toFixed(1)+'%':'0%');
 if(ma&&!paused&&idx>=0&&!fin){const b=new Uint8Array(ma.fftSize);ma.getByteTimeDomainData(b);
  let s=0;for(const v of b)s+=((v-128)/128)**2;if(Math.sqrt(s/b.length)>.04){score+=dt*60;$('sc').textContent='⭐ '+Math.floor(score)}}
 if(pos>end&&!fin){fin=1;clearInterval(iv);$('pb').textContent='▶';
  const p=Math.floor(score);say(mc?(p>2500?'Superstar! 🌟 ':p>1200?'Ang galing! 🔥 ':'Magaling! 👏 ')+'Puntos mo: '+p:'Tapos na!');
  if(qi<queue.length-1)setTimeout(()=>{if(fin&&qi<queue.length-1){qi++;load()}},2500)}
}
browse();requestAnimationFrame(tick);
