// Kantahan synth engine (Web Audio): drums, bass and chords made in code.

const ST={
pop:{k:[0,8,10],s:[4,12],h:[0,2,4,6,8,10,12,14],bs:[0,6,8,14],bt:'triangle',c:[0,6,10],ct:'sawtooth',cl:1800,cd:.25,cv:.07},
ballad:{k:[0,10],s:[8],sv:.12,h:[],bs:[0],bt:'sine',bl:.9,c:[0,2,4,6,8,10,12,14],ct:'triangle',cl:2600,cd:.5,cv:.12,arp:1},
reggae:{k:[8],s:[8],h:[0,2,4,6,8,10,12,14],hv:.05,bs:[0,3,8,11],bt:'triangle',c:[4,12],ct:'square',cl:1500,cd:.12,cv:.05},
rock:{k:[0,6,8,14],s:[4,12],h:[0,2,4,6,8,10,12,14],bs:[0,2,4,6,8,10,12,14],bt:'sawtooth',bl:420,c:[0,4,8,12],ct:'sawtooth',cl:1300,cd:.4,cv:.07,pw:1},
edm:{k:[0,4,8,12],s:[4,12],h:[2,6,10,14],bs:[2,6,10,14],bt:'sawtooth',bl:500,c:[0,3,6,10],ct:'sawtooth',cl:2400,cd:.2,cv:.06}};
let ctx,M,an,NB,song=null,tr=0,t0=0,nt=0,n=0,iv=0,fin=1,started=0,mc=null,wet=null,ma=null,score=0,cur=-1,lastT=0,paused=0;
const INTRO=2,BPL=2;
const mf=m=>440*2**((m-69)/12);
function init(){
 if(ctx)return;
 ctx=new (window.AudioContext||window.webkitAudioContext)();
 M=ctx.createGain();M.gain.value=.7;an=ctx.createAnalyser();an.fftSize=128;
 M.connect(an);an.connect(ctx.destination);
 NB=ctx.createBuffer(1,ctx.sampleRate,ctx.sampleRate);
 const d=NB.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=Math.random()*2-1;
}
function nz(t,d,f,v){const b=ctx.createBufferSource(),h=ctx.createBiquadFilter(),g=ctx.createGain();
 b.buffer=NB;h.type='highpass';h.frequency.value=f;g.gain.setValueAtTime(v,t);g.gain.exponentialRampToValueAtTime(.001,t+d);
 b.connect(h);h.connect(g);g.connect(M);b.start(t);b.stop(t+d)}
function kick(t){const o=ctx.createOscillator(),g=ctx.createGain();
 o.frequency.setValueAtTime(150,t);o.frequency.exponentialRampToValueAtTime(42,t+.12);
 g.gain.setValueAtTime(.95,t);g.gain.exponentialRampToValueAtTime(.001,t+.32);
 o.connect(g);g.connect(M);o.start(t);o.stop(t+.34)}
function tone(f,t,d,ty,v,lp){const o=ctx.createOscillator(),g=ctx.createGain(),l=ctx.createBiquadFilter();
 o.type=ty;o.frequency.value=f;l.type='lowpass';l.frequency.value=lp;
 g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(v,t+.012);g.gain.exponentialRampToValueAtTime(.001,t+d);
 o.connect(l);l.connect(g);g.connect(M);o.start(t);o.stop(t+d+.05)}
function step(t,i){
 const S=ST[song.s],sp=i%16,bar=Math.floor(i/16),[r0,mn]=song.p[bar%song.p.length],sd=60/song.b/4;
 const r=48+song.k+tr+r0,ch=[r,r+(mn?3:4),r+7,r+12];
 if(S.k.includes(sp))kick(t);
 if(S.s.includes(sp))nz(t,.16,1500,S.sv||.35);
 if(S.h.includes(sp))nz(t,.04,7000,S.hv||.1);
 if(S.bs.includes(sp))tone(mf(r-12),t,S.bs.length<3?sd*14:sd*1.8,S.bt,.4,S.bl||600);
 if(S.c.includes(sp)){
  if(S.arp)tone(mf(ch[(sp/2)%4]+12),t,S.cd*1.6,S.ct,S.cv,S.cl);
  else (S.pw?[ch[0],ch[2],ch[3]]:ch.slice(0,3)).forEach(m=>tone(mf(m+12),t,S.cd*(S.pw?1:1),S.ct,S.cv,S.cl));
 }
}
function sched(){while(nt<ctx.currentTime+.15){step(nt,n);nt+=60/song.b/4;n++}}
