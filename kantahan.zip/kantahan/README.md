# Kantahan 🎤
Karaoke web app na may sariling backing music (synthesized sa browser). Walang server, walang install.

## Files
- `index.html` – layout (sidebar, genres/songs, player)
- `css/style.css` – itsura
- `js/songs.js` – listahan ng kanta at lyrics (dito ka magdagdag ng bago)
- `js/engine.js` – gumagawa ng drums, bass at chords gamit ang Web Audio
- `js/app.js` – UI: genres, search, favorites, queue, mic, puntos

## Ilagay sa GitHub Pages
1. Gumawa ng bagong repo sa GitHub at i-upload ang lahat ng laman ng folder na ito.
2. Settings → Pages → Branch: `main` / root → Save.
3. Bubukas ang app sa `https://<username>.github.io/<repo>/`.

## Magdagdag ng kanta
Kopyahin ang isang object sa `js/songs.js` at palitan ang `n` (title), `a` (artist), `s` (pop, ballad, reggae, rock, edm), `b` (BPM), `p` (chords) at `L` (lyrics, 1 linya = 2 bars).
Gumamit lang ng mga kantang original o public domain.
